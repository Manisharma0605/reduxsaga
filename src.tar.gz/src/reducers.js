const initialState = {
    name:"Ashish"
}
const todos = (state = initialState, action) => {
    switch (action.type) {
      case 'ADD_TODO_SAGA':
        return {
            ...state,
            name : action.user
        }
      default:
        return state
    }
  }
  export default todos