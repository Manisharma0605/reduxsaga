import {put, takeEvery,  } from 'redux-saga/effects'

function* fetchUser(action) {
  
      yield put({type: "ADD_TODO_SAGA", user: 'Name Test'});
  
}


function* mySaga() {
  yield takeEvery("ADD_TODO", fetchUser);
}

export default mySaga;