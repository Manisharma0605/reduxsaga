export const addTodo = () => ({
  type: 'ADD_TODO',
})
