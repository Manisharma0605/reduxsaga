import React from 'react';
import { connect } from 'react-redux';
import {addTodo} from './actions'
import './App.css';

function App(props) {
  return (
    <div className="App">
      <p>{props.name}</p>
      <span onClick={props.changeName}>Name change</span>
    </div>
  );
}

const mapStateToProps = state =>({
  name : state.name
})

const mapDispatchToProps = dispatch =>({
  changeName: () => dispatch(addTodo())
})


export default connect(mapStateToProps, mapDispatchToProps)(App);
